# Gestionale Darevô — Architettura Tecnica

## Stack tecnologico

```
Frontend   React 18 + Vite + Tailwind CSS
Backend    Supabase (PostgreSQL + Auth + Storage + Realtime)
AI         Anthropic Claude API (claude-sonnet-4-6)
Deploy     Vercel (frontend) + Supabase Cloud (backend)
```

## Struttura progetto

```
darevo/
├── README.md
├── package.json
├── vite.config.js
├── tailwind.config.js
├── .env.example
├── supabase/
│   └── schema.sql          ← schema DB completo
├── src/
│   ├── main.jsx
│   ├── App.jsx
│   ├── lib/
│   │   ├── supabase.js     ← client Supabase
│   │   └── claude.js       ← client Claude API
│   ├── pages/
│   │   ├── CRM.jsx
│   │   ├── Appuntamenti.jsx
│   │   ├── Preventivi.jsx
│   │   ├── Commesse.jsx
│   │   ├── SAL.jsx
│   │   ├── Sicurezza.jsx
│   │   └── Subappalto.jsx
│   ├── components/
│   │   ├── Layout.jsx
│   │   ├── AIPanel.jsx
│   │   ├── Preventivatore.jsx
│   │   └── KanbanBoard.jsx
│   └── data/
│       └── voci.js         ← 69 voci capitolato
```

## Deploy in 4 passi

1. `npm install`
2. Crea progetto su supabase.com → copia URL e anon key in `.env`
3. Incolla `supabase/schema.sql` nell'editor SQL di Supabase
4. `vercel deploy` oppure `npm run build` + upload su qualsiasi hosting statico

## Variabili d'ambiente (.env)

```
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...
VITE_ANTHROPIC_API_KEY=sk-ant-...
```
