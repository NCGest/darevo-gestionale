/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef2ff',
          500: '#3b5bdb',
          600: '#2f4ac5',
          900: '#1a2a7a',
        }
      }
    }
  },
  plugins: [],
}
