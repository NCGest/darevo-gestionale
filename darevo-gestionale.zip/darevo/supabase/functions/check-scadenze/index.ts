// supabase/functions/check-scadenze/index.ts
// Viene eseguita ogni giorno via pg_cron — invia email alert per scadenze sicurezza

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import { Resend } from 'https://esm.sh/resend@3'

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
)
const resend = new Resend(Deno.env.get('RESEND_API_KEY'))

Deno.serve(async () => {
  const oggi = new Date()

  // Documenti in scadenza nei prossimi 30 giorni o già scaduti
  const { data: docs } = await supabase
    .from('documenti_sicurezza')
    .select('*, commesse(codice, clienti(nome, cognome))')
    .lte('data_scadenza', new Date(oggi.getTime() + 30 * 86400000).toISOString().split('T')[0])
    .not('status', 'eq', 'Valido')
    .order('data_scadenza')

  if (!docs?.length) return new Response('Nessuna scadenza', { status: 200 })

  // Aggiorna status documenti
  for (const doc of docs) {
    const scadenza = new Date(doc.data_scadenza)
    const giorniMancanti = Math.ceil((scadenza.getTime() - oggi.getTime()) / 86400000)

    const nuovoStatus = giorniMancanti < 0
      ? 'Scaduto'
      : giorniMancanti <= 7 ? 'In scadenza'
      : 'In scadenza'

    await supabase
      .from('documenti_sicurezza')
      .update({ status: nuovoStatus })
      .eq('id', doc.id)
  }

  // Invia email di riepilogo
  const scaduti = docs.filter(d => new Date(d.data_scadenza) < oggi)
  const inScadenza = docs.filter(d => new Date(d.data_scadenza) >= oggi)

  const htmlBody = `
    <h2>🔔 Report scadenze sicurezza — Darevô</h2>
    <p><strong>Data:</strong> ${oggi.toLocaleDateString('it-IT')}</p>

    ${scaduti.length ? `
    <h3 style="color:#A32D2D">⛔ Documenti scaduti (${scaduti.length})</h3>
    <ul>
      ${scaduti.map(d => `<li><strong>${d.nome_documento}</strong> — ${d.intestatario || ''} — scaduto il ${new Date(d.data_scadenza).toLocaleDateString('it-IT')}</li>`).join('')}
    </ul>` : ''}

    ${inScadenza.length ? `
    <h3 style="color:#BA7517">⚠️ In scadenza entro 30 giorni (${inScadenza.length})</h3>
    <ul>
      ${inScadenza.map(d => {
        const gg = Math.ceil((new Date(d.data_scadenza).getTime() - oggi.getTime()) / 86400000)
        return `<li><strong>${d.nome_documento}</strong> — ${d.intestatario || ''} — scade tra <strong>${gg} giorni</strong> (${new Date(d.data_scadenza).toLocaleDateString('it-IT')})</li>`
      }).join('')}
    </ul>` : ''}

    <p><a href="${Deno.env.get('APP_URL')}/sicurezza">Vai al modulo Sicurezza →</a></p>
  `

  await resend.emails.send({
    from: 'gestionale@darevo.it',
    to: ['admin@darevo.it'],
    subject: `[Darevô] ${scaduti.length} scaduti · ${inScadenza.length} in scadenza`,
    html: htmlBody,
  })

  return new Response(JSON.stringify({ scaduti: scaduti.length, inScadenza: inScadenza.length }), {
    headers: { 'Content-Type': 'application/json' },
  })
})
