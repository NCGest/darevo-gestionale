-- ============================================================
-- GESTIONALE DAREVÔ — Schema PostgreSQL (Supabase)
-- Eseguire nell'editor SQL di Supabase una volta sola
-- ============================================================

-- Abilita UUID
create extension if not exists "uuid-ossp";

-- ============================================================
-- TABELLA: utenti / team
-- ============================================================
create table if not exists public.profili (
  id          uuid references auth.users on delete cascade primary key,
  nome        text not null,
  cognome     text not null,
  ruolo       text not null default 'architetto'
                check (ruolo in ('direttore','area_manager','architetto','store_manager','front_office')),
  store       text,
  email       text,
  telefono    text,
  avatar_url  text,
  attivo      boolean not null default true,
  created_at  timestamptz not null default now()
);

-- ============================================================
-- TABELLA: lead / appuntamenti
-- ============================================================
create table if not exists public.lead (
  id              uuid primary key default uuid_generate_v4(),
  codice          text unique not null,          -- es. "10001"
  data_inserimento date not null default now(),
  provenienza     text not null
                  check (provenienza in ('Online','Store','Diretto','Passaparola','Architetto')),
  nome            text not null,
  cognome         text not null,
  telefono        text,
  email           text,
  indirizzo       text,
  tipo_commessa   text not null
                  check (tipo_commessa in ('Ristrutturazione','Consulenza','Progettazione/DL','Finiture/Arredi','Consulenza architettonica')),
  mq_immobile     numeric,
  mq_intervento   numeric,
  budget_stimato  numeric,
  note            text,
  stato           text not null default 'Nuovo'
                  check (stato in ('Nuovo','Fissato','Trattativa','Firmato','KO')),
  architetto_id   uuid references public.profili(id),
  store           text,
  finanziamento   boolean default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ============================================================
-- TABELLA: appuntamenti
-- ============================================================
create table if not exists public.appuntamenti (
  id              uuid primary key default uuid_generate_v4(),
  lead_id         uuid references public.lead(id) on delete cascade,
  data_ora        timestamptz not null,
  indirizzo       text,
  tipo            text not null default 'Sopralluogo'
                  check (tipo in ('Sopralluogo','Presentazione preventivo','Prima consulenza','Firma contratto','Altro')),
  architetto_id   uuid references public.profili(id),
  note            text,
  foto_urls       text[],
  planimetrie_urls text[],
  scheda_url      text,
  stato           text not null default 'Fissato'
                  check (stato in ('Fissato','Confermato','Effettuato','Annullato')),
  created_at      timestamptz not null default now()
);

-- ============================================================
-- TABELLA: commesse
-- ============================================================
create table if not exists public.commesse (
  id                uuid primary key default uuid_generate_v4(),
  codice            text unique not null,          -- es. "CNT-001"
  lead_id           uuid references public.lead(id),
  nome              text not null,
  cognome           text not null,
  indirizzo_cantiere text not null,
  indirizzo_residenza text,
  cf                text,
  piva              text,
  foglio            text,
  particella        text,
  subalterno        text,
  tipo_commessa     text not null,
  architetto_id     uuid references public.profili(id),
  store             text,
  data_validazione  date,
  data_inizio       date,
  durata_gg         integer,
  data_fine_stimata date,
  stato             text not null default 'Programmata'
                    check (stato in ('Programmata','In partenza','In corso','In chiusura','Chiusa','Sospesa','Contenzioso')),
  importo_totale    numeric not null default 0,
  importo_cantiere  numeric not null default 0,
  importo_finiture  numeric default 0,
  importo_consulenza numeric default 0,
  sal_percentuale   numeric default 0 check (sal_percentuale between 0 and 100),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

-- ============================================================
-- TABELLA: preventivi
-- ============================================================
create table if not exists public.preventivi (
  id              uuid primary key default uuid_generate_v4(),
  codice          text unique not null,            -- es. "PRV-001"
  commessa_id     uuid references public.commesse(id),
  lead_id         uuid references public.lead(id),
  architetto_id   uuid references public.profili(id),
  listino         text not null default 'lomb'
                  check (listino in ('lomb','lombMkt','dei','milano')),
  stato           text not null default 'Bozza'
                  check (stato in ('Bozza','In revisione','Inviato','Firmato','Rifiutato')),
  totale_lavori   numeric not null default 0,
  totale_finiture numeric default 0,
  totale_consulenza numeric default 0,
  totale_preventivo numeric not null default 0,
  note            text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ============================================================
-- TABELLA: righe preventivo (computo metrico)
-- ============================================================
create table if not exists public.preventivo_righe (
  id              uuid primary key default uuid_generate_v4(),
  preventivo_id   uuid references public.preventivi(id) on delete cascade,
  codice_voce     text not null,                   -- es. "LE.04"
  descrizione     text not null,
  um              text not null,
  quantita        numeric not null default 1,
  prezzo_unitario numeric not null,
  listino         text not null,
  inc_materiale   numeric,
  marg_lordo      numeric,
  marg_netto      numeric,
  ordine          integer default 0,
  created_at      timestamptz not null default now()
);

-- ============================================================
-- TABELLA: SAL (stati avanzamento lavori)
-- ============================================================
create table if not exists public.sal (
  id              uuid primary key default uuid_generate_v4(),
  commessa_id     uuid references public.commesse(id) on delete cascade,
  numero          integer not null,
  data            date not null default now(),
  percentuale     numeric not null check (percentuale between 0 and 100),
  importo_maturato numeric not null default 0,
  importo_fatturato numeric default 0,
  note            text,
  created_by      uuid references public.profili(id),
  created_at      timestamptz not null default now()
);

-- ============================================================
-- TABELLA: pagamenti
-- ============================================================
create table if not exists public.pagamenti (
  id              uuid primary key default uuid_generate_v4(),
  commessa_id     uuid references public.commesse(id) on delete cascade,
  tipo            text not null
                  check (tipo in ('Cantiere','Sicurezza','Extra','Finiture','Arredi','Serramenti','Consulenza')),
  numero_rata     integer,
  trigger_sal     text,
  importo         numeric not null,
  percentuale     numeric,
  data_scadenza   date,
  data_incasso    date,
  stato           text not null default 'Da emettere'
                  check (stato in ('Da emettere','Emessa','Incassata','In ritardo')),
  note            text,
  created_at      timestamptz not null default now()
);

-- ============================================================
-- TABELLA: lavori extra
-- ============================================================
create table if not exists public.lavori_extra (
  id              uuid primary key default uuid_generate_v4(),
  commessa_id     uuid references public.commesse(id) on delete cascade,
  descrizione     text not null,
  richiesto_da    text not null check (richiesto_da in ('Cliente','Architetto','Direzione lavori','Altro')),
  importo         numeric not null,
  giorni_extra    integer default 0,
  data            date not null default now(),
  stato           text not null default 'In attesa'
                  check (stato in ('In attesa','Approvato','Rifiutato')),
  preventivo_extra_url text,
  created_at      timestamptz not null default now()
);

-- ============================================================
-- TABELLA: documenti sicurezza
-- ============================================================
create table if not exists public.sicurezza (
  id              uuid primary key default uuid_generate_v4(),
  commessa_id     uuid references public.commesse(id),  -- null = aziendale
  tipo            text not null
                  check (tipo in ('POS','DVR','DURC','PSC','Notifica CPIA','Formazione','Visita medica','Incarico CSE','Incarico ARCH','Altro')),
  descrizione     text not null,
  riferimento     text,                                  -- es. "Mario Bianchi"
  data_emissione  date,
  data_scadenza   date,
  stato           text not null default 'Valido'
                  check (stato in ('Valido','In scadenza','Scaduto','Da redigere','Inviato')),
  documento_url   text,
  note            text,
  created_at      timestamptz not null default now()
);

-- ============================================================
-- TABELLA: subappaltatori
-- ============================================================
create table if not exists public.subappaltatori (
  id              uuid primary key default uuid_generate_v4(),
  ragione_sociale text not null,
  referente       text,
  telefono        text,
  email           text,
  specializzazione text not null,
  durc_scadenza   date,
  stato           text not null default 'Qualificato'
                  check (stato in ('Qualificato','In valutazione','Sospeso','Blacklist')),
  note            text,
  created_at      timestamptz not null default now()
);

-- ============================================================
-- TABELLA: ordini subappalto
-- ============================================================
create table if not exists public.ordini_subappalto (
  id                uuid primary key default uuid_generate_v4(),
  commessa_id       uuid references public.commesse(id) on delete cascade,
  subappaltatore_id uuid references public.subappaltatori(id),
  lavorazione       text not null,
  importo           numeric not null,
  data_ordine       date not null default now(),
  data_inizio       date,
  data_fine         date,
  stato             text not null default 'In attesa preventivo'
                    check (stato in ('In attesa preventivo','In revisione','Approvato','In corso','Completato','Annullato')),
  documento_url     text,
  note              text,
  created_at        timestamptz not null default now()
);

-- ============================================================
-- VISTE UTILI
-- ============================================================

-- Vista pipeline CRM con info aggregate
create or replace view public.v_pipeline as
select
  l.id, l.codice, l.nome, l.cognome, l.telefono, l.email,
  l.indirizzo, l.tipo_commessa, l.mq_immobile, l.budget_stimato,
  l.stato, l.provenienza, l.note, l.created_at,
  p.nome || ' ' || p.cognome as architetto_nome
from public.lead l
left join public.profili p on l.architetto_id = p.id;

-- Vista KPI commesse
create or replace view public.v_commesse_kpi as
select
  c.id, c.codice, c.nome, c.cognome,
  c.tipo_commessa, c.stato, c.importo_totale,
  c.importo_cantiere, c.sal_percentuale,
  c.data_inizio, c.data_fine_stimata,
  c.importo_cantiere * c.sal_percentuale / 100 as importo_maturato,
  p.nome || ' ' || p.cognome as architetto_nome,
  (select coalesce(sum(pg.importo),0)
   from public.pagamenti pg
   where pg.commessa_id = c.id and pg.stato = 'Incassata') as incassato
from public.commesse c
left join public.profili p on c.architetto_id = p.id;

-- ============================================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================================
alter table public.profili       enable row level security;
alter table public.lead          enable row level security;
alter table public.appuntamenti  enable row level security;
alter table public.commesse      enable row level security;
alter table public.preventivi    enable row level security;
alter table public.preventivo_righe enable row level security;
alter table public.sal           enable row level security;
alter table public.pagamenti     enable row level security;
alter table public.lavori_extra  enable row level security;
alter table public.sicurezza     enable row level security;
alter table public.subappaltatori enable row level security;
alter table public.ordini_subappalto enable row level security;

-- Policy: utenti autenticati possono leggere e scrivere tutto
-- (personalizzare per ruolo in produzione)
create policy "Autenticati full access" on public.lead
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.commesse
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.preventivi
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.preventivo_righe
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.appuntamenti
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.sal
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.pagamenti
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.lavori_extra
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.sicurezza
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.subappaltatori
  for all using (auth.role() = 'authenticated');
create policy "Autenticati full access" on public.ordini_subappalto
  for all using (auth.role() = 'authenticated');
create policy "Profili propri" on public.profili
  for all using (auth.uid() = id);

-- ============================================================
-- FUNZIONE: aggiorna updated_at automaticamente
-- ============================================================
create or replace function public.handle_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger on_lead_updated
  before update on public.lead
  for each row execute procedure public.handle_updated_at();

create trigger on_commessa_updated
  before update on public.commesse
  for each row execute procedure public.handle_updated_at();

create trigger on_preventivo_updated
  before update on public.preventivi
  for each row execute procedure public.handle_updated_at();

-- ============================================================
-- STORAGE BUCKET per documenti
-- ============================================================
insert into storage.buckets (id, name, public)
values ('documenti', 'documenti', false)
on conflict do nothing;

-- Policy storage: solo utenti autenticati
create policy "Autenticati upload documenti"
  on storage.objects for insert
  with check (bucket_id = 'documenti' and auth.role() = 'authenticated');

create policy "Autenticati read documenti"
  on storage.objects for select
  using (bucket_id = 'documenti' and auth.role() = 'authenticated');
