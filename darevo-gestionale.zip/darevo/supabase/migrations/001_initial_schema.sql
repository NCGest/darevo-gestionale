-- ============================================================
-- GESTIONALE DAREVÔ — Schema PostgreSQL completo
-- Supabase Migration: 001_initial_schema.sql
-- ============================================================

-- Abilita estensioni utili
create extension if not exists "uuid-ossp";
create extension if not exists "pg_cron";

-- ============================================================
-- ENUM TYPES
-- ============================================================
create type lead_status as enum ('Nuovo','Fissato','Trattativa','Firmato','KO');
create type lead_source as enum ('Online','Store','Diretto','Passaparola','Architetto');
create type job_type as enum ('Ristrutturazione','Consulenza','Progettazione/DL','Finiture/Arredi');
create type commessa_status as enum ('Da validare','In partenza','In corso','In chiusura','Chiusa','Contenzioso','Sospesa');
create type prev_status as enum ('Bozza','In revisione','Inviato','Firmato','Annullato');
create type listino_type as enum ('Regione Lombardia','Media Lombardia','DEI','Milano');
create type doc_status as enum ('Valido','In scadenza','Scaduto','Da rinnovare','Da redigere');
create type payment_status as enum ('Da emettere','In attesa SAL','Emessa','Incassata','Scaduta');

-- ============================================================
-- ANAGRAFICA CLIENTI (tabella master)
-- ============================================================
create table clienti (
  id          uuid primary key default uuid_generate_v4(),
  codice      serial unique,           -- COD. CLIENTE auto-incrementale
  nome        text not null,
  cognome     text not null,
  telefono    text,
  email       text,
  indirizzo   text,
  codice_fiscale text,
  piva        text,
  note        text,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);

-- ============================================================
-- LEAD / APPUNTAMENTI (pipeline commerciale)
-- ============================================================
create table leads (
  id              uuid primary key default uuid_generate_v4(),
  cliente_id      uuid references clienti(id) on delete set null,
  -- Dati lead (anche senza cliente registrato)
  nome            text not null,
  cognome         text not null,
  telefono        text,
  email           text,
  indirizzo       text,
  provenienza     lead_source default 'Online',
  tipo_lavoro     job_type default 'Ristrutturazione',
  mq_stimati      numeric(6,1),
  budget_stimato  numeric(10,2),
  note            text,
  status          lead_status default 'Nuovo',
  -- Appuntamento
  data_appuntamento timestamptz,
  note_appuntamento text,
  finanziamento   boolean default false,
  -- Assegnazioni
  architetto      text,
  store           text,
  -- Dati immobile
  mq_immobile     numeric(6,1),
  mq_intervento   numeric(6,1),
  piano_intervento text,
  -- Tracciamento
  data_inserimento date default current_date,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- ============================================================
-- PREVENTIVI
-- ============================================================
create table preventivi (
  id            uuid primary key default uuid_generate_v4(),
  codice        text unique not null,  -- es: PRV-2026-001
  cliente_id    uuid references clienti(id),
  lead_id       uuid references leads(id),
  listino       listino_type default 'Regione Lombardia',
  status        prev_status default 'Bozza',
  architetto    text,
  note          text,
  -- Totali (calcolati dai righe ma salvati per performance)
  totale_lavori numeric(12,2) default 0,
  totale_finiture numeric(12,2) default 0,
  totale_consulenza numeric(12,2) default 0,
  totale_preventivo numeric(12,2) default 0,
  margine_lordo_pct numeric(5,2),
  margine_netto_pct numeric(5,2),
  -- Date
  data_creazione date default current_date,
  data_scadenza  date,
  data_firma     date,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

-- Righe del computo metrico
create table preventivi_righe (
  id              uuid primary key default uuid_generate_v4(),
  preventivo_id   uuid references preventivi(id) on delete cascade,
  ordinamento     integer not null default 0,
  -- Voce di capitolato
  voce_cod        text,               -- es: LE.04
  descrizione     text not null,
  unita_misura    text,
  quantita        numeric(10,3) not null default 1,
  prezzo_unitario numeric(10,2) not null,
  totale_riga     numeric(12,2) generated always as (quantita * prezzo_unitario) stored,
  -- Analisi costi
  inc_materiale   numeric(5,3),       -- incidenza materiale (0.0–1.0)
  marg_lordo_pct  numeric(5,3),
  marg_netto_pct  numeric(5,3),
  -- Note di riga
  note            text,
  created_at      timestamptz default now()
);

-- ============================================================
-- COMMESSE (cantieri)
-- ============================================================
create table commesse (
  id                  uuid primary key default uuid_generate_v4(),
  codice              text unique not null,   -- es: CNT-2026-001
  preventivo_id       uuid references preventivi(id),
  cliente_id          uuid references clienti(id),
  lead_id             uuid references leads(id),
  tipo_lavoro         job_type,
  status              commessa_status default 'Da validare',
  architetto          text,
  store               text,
  store_manager       text,
  -- Importi contratto
  importo_totale      numeric(12,2),
  importo_cantiere    numeric(12,2),
  importo_finiture    numeric(12,2),
  importo_consulenza  numeric(12,2),
  -- Date
  data_validazione    date,
  data_inizio         date,
  durata_giorni       integer,
  data_fine_stimata   date,
  data_fine_effettiva date,
  -- Dati catastali
  foglio              text,
  particella          text,
  subalterno          text,
  -- SAL corrente (calcolato ma cachato)
  sal_percentuale     numeric(5,2) default 0,
  sal_importo         numeric(12,2) default 0,
  -- Contabilità
  totale_fatturato    numeric(12,2) default 0,
  totale_incassato    numeric(12,2) default 0,
  totale_costi        numeric(12,2) default 0,
  note                text,
  created_at          timestamptz default now(),
  updated_at          timestamptz default now()
);

-- SAL (stati di avanzamento lavori)
create table sal_voci (
  id              uuid primary key default uuid_generate_v4(),
  commessa_id     uuid references commesse(id) on delete cascade,
  fase            text not null,
  importo_fase    numeric(12,2),
  avanzamento_pct numeric(5,2) default 0,
  note            text,
  data_rilevazione date default current_date,
  created_at      timestamptz default now()
);

-- Pagamenti
create table pagamenti (
  id              uuid primary key default uuid_generate_v4(),
  commessa_id     uuid references commesse(id) on delete cascade,
  rata_numero     integer not null,
  trigger_sal     text,               -- es: "SAL 50%"
  importo         numeric(12,2) not null,
  percentuale     numeric(5,2),
  status          payment_status default 'Da emettere',
  data_scadenza   date,
  data_emissione  date,
  data_incasso    date,
  note_fattura    text,
  created_at      timestamptz default now()
);

-- Lavori extra
create table lavori_extra (
  id              uuid primary key default uuid_generate_v4(),
  commessa_id     uuid references commesse(id) on delete cascade,
  descrizione     text not null,
  richiesto_da    text,
  importo         numeric(10,2),
  approvato       boolean default false,
  data_richiesta  date default current_date,
  note            text,
  created_at      timestamptz default now()
);

-- ============================================================
-- SICUREZZA (documenti e scadenze)
-- ============================================================
create table documenti_sicurezza (
  id              uuid primary key default uuid_generate_v4(),
  commessa_id     uuid references commesse(id) on delete set null,  -- null = aziendale
  categoria       text not null,  -- 'Cantiere','Aziendale','Formazione','Lavoratore'
  nome_documento  text not null,
  intestatario    text,           -- nome lavoratore o azienda
  data_emissione  date,
  data_scadenza   date,
  status          doc_status default 'Da redigere',
  file_url        text,           -- Supabase Storage URL
  note            text,
  -- Alert: giorni prima della scadenza per notificare
  alert_giorni    integer default 30,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- ============================================================
-- SUBAPPALTATORI
-- ============================================================
create table subappaltatori (
  id              uuid primary key default uuid_generate_v4(),
  ragione_sociale text not null,
  specializzazione text,
  referente       text,
  telefono        text,
  email           text,
  piva            text,
  durc_scadenza   date,
  qualificato     boolean default false,
  note            text,
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

-- Ordini/contratti subappalto per commessa
create table subappalto_ordini (
  id                  uuid primary key default uuid_generate_v4(),
  commessa_id         uuid references commesse(id) on delete cascade,
  subappaltatore_id   uuid references subappaltatori(id),
  lavorazione         text not null,
  importo_preventivo  numeric(12,2),
  importo_finale      numeric(12,2),
  status              text default 'In attesa prev.',
  data_ordine         date,
  note                text,
  created_at          timestamptz default now()
);

-- ============================================================
-- GIORNALE DI CANTIERE
-- ============================================================
create table giornale_cantiere (
  id              uuid primary key default uuid_generate_v4(),
  commessa_id     uuid references commesse(id) on delete cascade,
  data_registrazione date default current_date,
  lavoratori_presenti integer,
  attivita        text not null,
  note_meteo      text,
  problemi        text,
  foto_urls       text[],         -- array di URL Supabase Storage
  created_at      timestamptz default now()
);

-- ============================================================
-- ROW LEVEL SECURITY (accesso solo a utenti autenticati Darevô)
-- ============================================================
alter table clienti enable row level security;
alter table leads enable row level security;
alter table preventivi enable row level security;
alter table preventivi_righe enable row level security;
alter table commesse enable row level security;
alter table sal_voci enable row level security;
alter table pagamenti enable row level security;
alter table lavori_extra enable row level security;
alter table documenti_sicurezza enable row level security;
alter table subappaltatori enable row level security;
alter table subappalto_ordini enable row level security;
alter table giornale_cantiere enable row level security;

-- Policy: accesso completo agli utenti autenticati (singola azienda)
-- Per multi-tenant aggiungere colonna company_id e policy per company
do $$
declare
  t text;
begin
  foreach t in array array[
    'clienti','leads','preventivi','preventivi_righe',
    'commesse','sal_voci','pagamenti','lavori_extra',
    'documenti_sicurezza','subappaltatori','subappalto_ordini','giornale_cantiere'
  ]
  loop
    execute format(
      'create policy "Utenti autenticati" on %I for all to authenticated using (true) with check (true)', t
    );
  end loop;
end$$;

-- ============================================================
-- INDICI per performance
-- ============================================================
create index on leads (status);
create index on leads (data_appuntamento);
create index on commesse (status);
create index on commesse (data_fine_stimata);
create index on preventivi (status);
create index on preventivi_righe (preventivo_id);
create index on pagamenti (status, data_scadenza);
create index on documenti_sicurezza (data_scadenza, status);
create index on subappalto_ordini (commessa_id);

-- ============================================================
-- FUNZIONE: aggiorna updated_at automaticamente
-- ============================================================
create or replace function update_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

do $$
declare t text;
begin
  foreach t in array array['clienti','leads','preventivi','commesse','documenti_sicurezza','subappaltatori']
  loop
    execute format('create trigger trg_%s_updated before update on %I for each row execute function update_updated_at()', t, t);
  end loop;
end$$;

-- ============================================================
-- FUNZIONE: genera codice progressivo preventivi
-- ============================================================
create or replace function next_codice_preventivo()
returns text language plpgsql as $$
declare
  anno text := to_char(now(), 'YYYY');
  n    integer;
begin
  select coalesce(max(split_part(codice, '-', 3)::integer), 0) + 1
  into n
  from preventivi
  where codice like 'PRV-' || anno || '-%';
  return 'PRV-' || anno || '-' || lpad(n::text, 3, '0');
end;
$$;

create or replace function next_codice_commessa()
returns text language plpgsql as $$
declare
  anno text := to_char(now(), 'YYYY');
  n    integer;
begin
  select coalesce(max(split_part(codice, '-', 3)::integer), 0) + 1
  into n
  from commesse
  where codice like 'CNT-' || anno || '-%';
  return 'CNT-' || anno || '-' || lpad(n::text, 3, '0');
end;
$$;
