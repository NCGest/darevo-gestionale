import { useState, useEffect } from 'react'
import { Plus, Trash2, ChevronDown, ChevronUp } from 'lucide-react'
import { preventiviAPI } from '../lib/supabase'
import { VOCI } from '../data/voci'
import AIPanel from '../components/AIPanel'

const LISTINI = {
  lomb:    { label: 'Reg. Lombardia', field: 'lomb',    desc: 'Prezziario ufficiale Regione Lombardia 2024' },
  lombMkt: { label: 'Media Lomb.',    field: 'lombMkt', desc: 'Listino ×1,08 — mercato privato (CCIAA)' },
  dei:     { label: 'DEI 2024',       field: 'dei',     desc: 'Tipografia Genio Civile — riferimento nazionale' },
  milano:  { label: 'Prezzi Milano',  field: 'milano',  desc: 'Listino CCIAA Milano — +15/30% vs Lombardia' },
}

export default function Preventivi() {
  const [preventivi, setPreventivi] = useState([])
  const [selected, setSelected]     = useState(null)  // preventivo attivo
  const [righe, setRighe]           = useState([])    // righe computo
  const [listino, setListino]       = useState('lomb')
  const [search, setSearch]         = useState('')
  const [catFilter, setCatFilter]   = useState('')
  const [loading, setLoading]       = useState(true)

  useEffect(() => { loadList() }, [])

  async function loadList() {
    setLoading(true)
    const { data } = await preventiviAPI.getAll()
    setPreventivi(data ?? [])
    setLoading(false)
  }

  async function openPreventivo(prev) {
    const { data } = await preventiviAPI.getById(prev.id)
    setSelected(data)
    setRighe(data.preventivo_righe ?? [])
    setListino(data.listino ?? 'lomb')
  }

  async function newPreventivo() {
    const codice = 'PRV-' + String(preventivi.length + 1).padStart(3, '0')
    const { data } = await preventiviAPI.create({ codice, listino, totale_preventivo: 0, totale_lavori: 0 })
    setPreventivi(prev => [data, ...prev])
    await openPreventivo(data)
  }

  function addVoce(voce) {
    const existing = righe.find(r => r.codice_voce === voce.cod && r.listino === listino)
    if (existing) {
      setRighe(prev => prev.map(r => r.codice_voce === voce.cod && r.listino === listino
        ? { ...r, quantita: r.quantita + 1 } : r))
      return
    }
    setRighe(prev => [...prev, {
      id:             'tmp_' + Date.now(),
      codice_voce:    voce.cod,
      descrizione:    voce.desc,
      um:             voce.um,
      quantita:       1,
      prezzo_unitario: voce[listino],
      listino,
      inc_materiale:  voce.incMat,
      marg_lordo:     voce.margLordo,
      marg_netto:     voce.margNetto,
    }])
  }

  function removeRiga(id) { setRighe(prev => prev.filter(r => r.id !== id)) }

  function updateQty(id, val) {
    setRighe(prev => prev.map(r => r.id === id ? { ...r, quantita: parseFloat(val) || 1 } : r))
  }

  async function saveComputo() {
    if (!selected) return
    const totLav = righe.reduce((s, r) => s + r.quantita * r.prezzo_unitario, 0)
    await preventiviAPI.update(selected.id, { listino, totale_lavori: Math.round(totLav), totale_preventivo: Math.round(totLav) })
    await preventiviAPI.updateRighe(selected.id, righe.map(({ id, ...r }) => r))
    loadList()
  }

  const totale  = righe.reduce((s, r) => s + r.quantita * r.prezzo_unitario, 0)
  const totMat  = righe.reduce((s, r) => s + r.quantita * r.prezzo_unitario * (r.inc_materiale ?? 0), 0)
  const totMarg = righe.reduce((s, r) => s + r.quantita * r.prezzo_unitario * (r.marg_netto ?? 0), 0)
  const pctMarg = totale > 0 ? Math.round(totMarg / totale * 100) : 0

  const filteredVoci = VOCI.filter(v => {
    const txt = (v.desc + v.cod + v.um).toLowerCase()
    return (!search || txt.includes(search.toLowerCase())) &&
           (!catFilter || txt.includes(catFilter.toLowerCase()))
  })

  const aiContext = selected
    ? `Preventivo ${selected.codice} — Listino: ${LISTINI[listino].label}. Totale: €${Math.round(totale).toLocaleString('it-IT')}. Righe: ${righe.map(r => `${r.codice_voce} q.${r.quantita} €${Math.round(r.quantita*r.prezzo_unitario)}`).join(', ')}`
    : 'Nessun preventivo aperto.'

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      {/* Topbar */}
      <div className="bg-white border-b border-gray-100 px-5 py-3 flex items-center gap-3 flex-shrink-0">
        <h1 className="text-sm font-medium text-gray-800 mr-2">Preventivi</h1>
        <div className="flex gap-1">
          {Object.entries(LISTINI).map(([k, v]) => (
            <button key={k} onClick={() => setListino(k)}
              className={`px-2.5 py-1 text-[10px] rounded-md border transition-colors ${
                listino === k ? 'bg-blue-50 text-blue-600 border-blue-200 font-medium' : 'border-gray-200 text-gray-500 hover:bg-gray-50'
              }`}>
              {v.label}
            </button>
          ))}
        </div>
        <div className="text-[10px] text-gray-400 flex-1">{LISTINI[listino].desc}</div>
        <button onClick={newPreventivo} className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <Plus size={12} /> Nuovo
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Lista preventivi */}
        <div className="w-52 border-r border-gray-100 bg-white overflow-y-auto flex-shrink-0">
          {loading ? (
            <div className="p-4 text-xs text-gray-400">Caricamento...</div>
          ) : preventivi.map(p => (
            <div key={p.id} onClick={() => openPreventivo(p)}
              className={`px-3 py-2.5 border-b border-gray-50 cursor-pointer hover:bg-gray-50 ${selected?.id === p.id ? 'bg-blue-50' : ''}`}>
              <div className="text-[10px] font-medium text-gray-700">{p.codice}</div>
              <div className="text-[10px] text-gray-400">€{p.totale_preventivo?.toLocaleString('it-IT') || '—'}</div>
              <span className={`text-[8px] px-1.5 py-0.5 rounded-full font-medium ${
                p.stato === 'Firmato' ? 'bg-green-50 text-green-700' :
                p.stato === 'Bozza' ? 'bg-gray-100 text-gray-500' : 'bg-blue-50 text-blue-600'
              }`}>{p.stato}</span>
            </div>
          ))}
        </div>

        {/* Catalogo + Computo */}
        {selected ? (
          <div className="flex flex-1 overflow-hidden">
            {/* Catalogo voci */}
            <div className="w-72 border-r border-gray-100 flex flex-col overflow-hidden">
              <div className="p-2 border-b border-gray-100 flex flex-col gap-1.5">
                <input placeholder="Cerca voce..." value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 bg-gray-50" />
                <div className="flex gap-1 flex-wrap">
                  {[['','Tutte'],['demoli','Demolizioni'],['mass','Massetti'],['pav','Pavimenti'],['impianto','Impianti'],['pittur','Pitture'],['cartong','Cartongesso']].map(([k,l]) => (
                    <button key={k} onClick={() => { setCatFilter(k); setSearch('') }}
                      className={`text-[9px] px-2 py-0.5 rounded-full border transition-colors ${catFilter===k ? 'bg-blue-50 text-blue-600 border-blue-200' : 'border-gray-200 text-gray-400 hover:bg-gray-50'}`}>
                      {l}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex-1 overflow-y-auto">
                {filteredVoci.map(v => (
                  <div key={v.cod} className="flex items-start gap-2 px-3 py-2 border-b border-gray-50 hover:bg-gray-50">
                    <div className="flex-1 min-w-0">
                      <div className="text-[9px] text-gray-400 font-medium">{v.cod}</div>
                      <div className="text-[10px] text-gray-700 leading-snug">{v.desc}</div>
                      <div className="text-[9px] text-gray-400">{v.um} · MU {Math.round(v.margNetto*100)}%</div>
                    </div>
                    <div className="flex flex-col items-end gap-1 flex-shrink-0">
                      <div className="text-[11px] font-medium text-blue-600">€{v[listino]}</div>
                      <button onClick={() => addVoce(v)}
                        className="w-5 h-5 rounded-full border border-gray-200 bg-white text-blue-600 flex items-center justify-center hover:bg-blue-50 text-xs">+</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Computo */}
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="px-4 py-2.5 border-b border-gray-100 flex items-center justify-between bg-white flex-shrink-0">
                <span className="text-xs font-medium text-gray-700">{selected.codice} — Computo metrico</span>
                <button onClick={saveComputo} className="px-3 py-1.5 text-xs bg-green-600 text-white rounded-lg hover:bg-green-700">Salva</button>
              </div>

              <div className="flex-1 overflow-y-auto p-3 space-y-2">
                {righe.length === 0 ? (
                  <div className="flex items-center justify-center h-full text-xs text-gray-400">
                    Aggiungi voci dal catalogo →
                  </div>
                ) : righe.map(r => {
                  const tot = r.quantita * r.prezzo_unitario
                  return (
                    <div key={r.id} className="bg-white border border-gray-100 rounded-lg p-2.5">
                      <div className="flex items-start gap-2 mb-2">
                        <div className="flex-1">
                          <span className="text-[9px] text-gray-400 font-medium">{r.codice_voce}</span>
                          <div className="text-[10px] text-gray-700 leading-snug">{r.descrizione}</div>
                        </div>
                        <button onClick={() => removeRiga(r.id)} className="text-gray-300 hover:text-red-400"><Trash2 size={12} /></button>
                      </div>
                      <div className="flex items-center gap-2 text-[10px]">
                        <span className="text-gray-400 w-12">{r.um}</span>
                        <input type="number" value={r.quantita} min="0.1" step="0.5"
                          onChange={e => updateQty(r.id, e.target.value)}
                          className="w-14 border border-gray-200 rounded px-1.5 py-0.5 text-center bg-gray-50 text-gray-700" />
                        <span className="text-gray-400">× €{r.prezzo_unitario}</span>
                        <span className="ml-auto font-medium text-gray-800">€{Math.round(tot).toLocaleString('it-IT')}</span>
                      </div>
                      <div className="flex gap-3 mt-1 text-[9px] text-gray-400">
                        <span>Mat. €{Math.round(tot*(r.inc_materiale??0)).toLocaleString('it-IT')}</span>
                        <span className="text-green-600">M.netto €{Math.round(tot*(r.marg_netto??0)).toLocaleString('it-IT')} ({Math.round((r.marg_netto??0)*100)}%)</span>
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* Footer totali */}
              <div className="border-t border-gray-100 bg-white p-3 flex-shrink-0">
                <div className="grid grid-cols-4 gap-2">
                  {[
                    ['Totale lavori', '€'+Math.round(totale).toLocaleString('it-IT')],
                    ['Costo materiali', '€'+Math.round(totMat).toLocaleString('it-IT')],
                    ['Margine netto', '€'+Math.round(totMarg).toLocaleString('it-IT')],
                    ['% Margine', pctMarg+'%'],
                  ].map(([l,v]) => (
                    <div key={l} className="bg-gray-50 rounded-lg p-2">
                      <div className="text-[9px] text-gray-400">{l}</div>
                      <div className="text-sm font-medium text-gray-800">{v}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center text-sm text-gray-400">
            Seleziona o crea un preventivo
          </div>
        )}
      </div>

      <AIPanel
        context={aiContext}
        quickPrompts={[
          { label: '🔍 Verifica prezzi vs Listino Lombardia', prompt: 'I prezzi del computo sono allineati al Prezzario Regione Lombardia 2024? Segnala anomalie' },
          { label: '💡 Voci mancanti per ristrutturazione completa', prompt: 'Guardando le voci inserite, cosa manca tipicamente in una ristrutturazione completa?' },
          { label: '📄 Genera testo per il cliente',              prompt: 'Genera una lettera di presentazione del preventivo per il cliente, professionale e cordiale' },
          { label: '📊 Analisi margini computo',                  prompt: 'Analizza i margini voce per voce e suggerisci ottimizzazioni' },
        ]}
      />
    </div>
  )
}
