import { useState, useEffect } from 'react'
import { Plus, RefreshCw } from 'lucide-react'
import { leadAPI } from '../lib/supabase'
import AIPanel from '../components/AIPanel'

const STAGES    = ['Nuovo', 'Fissato', 'Trattativa', 'Firmato', 'KO']
const STAGE_LBL = { Nuovo: 'Nuovo', Fissato: 'App. fissato', Trattativa: 'In trattativa', Firmato: 'Firmato', KO: 'KO' }
const STAGE_CLR = { Nuovo: 'bg-gray-100', Fissato: 'bg-blue-50', Trattativa: 'bg-amber-50', Firmato: 'bg-green-50', KO: 'bg-red-50' }

const EMPTY_LEAD = {
  nome: '', cognome: '', telefono: '', email: '', indirizzo: '',
  provenienza: 'Online', tipo_commessa: 'Ristrutturazione',
  mq_immobile: '', budget_stimato: '', note: '', stato: 'Nuovo',
}

export default function CRM() {
  const [leads, setLeads]     = useState([])
  const [loading, setLoading] = useState(true)
  const [modal, setModal]     = useState(false)
  const [form, setForm]       = useState(EMPTY_LEAD)
  const [saving, setSaving]   = useState(false)

  useEffect(() => { load() }, [])

  async function load() {
    setLoading(true)
    const { data } = await leadAPI.getAll()
    setLeads(data ?? [])
    setLoading(false)
  }

  async function save() {
    setSaving(true)
    const codice = `1${String(Date.now()).slice(-4)}`
    await leadAPI.create({ ...form, codice, budget_stimato: form.budget_stimato || null, mq_immobile: form.mq_immobile || null })
    setModal(false)
    setForm(EMPTY_LEAD)
    setSaving(false)
    load()
  }

  async function updateStato(id, stato) {
    await leadAPI.updateStato(id, stato)
    setLeads(prev => prev.map(l => l.id === id ? { ...l, stato } : l))
  }

  const kpi = {
    tot:     leads.length,
    tratt:   leads.filter(l => l.stato === 'Trattativa').length,
    firmati: leads.filter(l => l.stato === 'Firmato').length,
    valore:  leads.filter(l => l.stato !== 'KO').reduce((s, l) => s + (l.budget_stimato || 0), 0),
  }

  const aiContext = `Pipeline lead Darevô: ${leads.map(l =>
    `${l.nome} ${l.cognome} (${l.stato}, budget €${l.budget_stimato || '?'}, ${l.tipo_commessa})`
  ).join('; ')}`

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      {/* Topbar */}
      <div className="bg-white border-b border-gray-100 px-5 py-3 flex items-center justify-between flex-shrink-0">
        <h1 className="text-sm font-medium text-gray-800">Pipeline Lead</h1>
        <div className="flex gap-2">
          <button onClick={load} className="flex items-center gap-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-lg text-gray-500 hover:bg-gray-50">
            <RefreshCw size={12} /> Aggiorna
          </button>
          <button onClick={() => setModal(true)} className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            <Plus size={12} /> Nuovo lead
          </button>
        </div>
      </div>

      {/* KPI */}
      <div className="grid grid-cols-4 gap-3 px-5 py-3 flex-shrink-0">
        {[
          { label: 'Lead totali',       value: kpi.tot,     sub: 'questo mese' },
          { label: 'In trattativa',     value: kpi.tratt,   sub: 'da seguire' },
          { label: 'Contratti firmati', value: kpi.firmati, sub: 'convertiti' },
          { label: 'Valore pipeline',   value: '€' + (kpi.valore >= 1000 ? Math.round(kpi.valore/1000) + 'k' : kpi.valore), sub: 'potenziale' },
        ].map(k => (
          <div key={k.label} className="bg-gray-50 rounded-lg p-3">
            <div className="text-[10px] text-gray-400 mb-0.5">{k.label}</div>
            <div className="text-xl font-medium text-gray-800">{k.value}</div>
            <div className="text-[9px] text-gray-400">{k.sub}</div>
          </div>
        ))}
      </div>

      {/* Kanban */}
      <div className="flex-1 overflow-x-auto px-5 pb-4">
        {loading ? (
          <div className="flex items-center justify-center h-full text-sm text-gray-400">Caricamento...</div>
        ) : (
          <div className="flex gap-3 h-full min-w-max">
            {STAGES.map(stage => {
              const stageleads = leads.filter(l => l.stato === stage)
              return (
                <div key={stage} className="w-52 flex flex-col">
                  <div className="flex items-center justify-between px-2 py-1.5 mb-1.5">
                    <span className="text-[10px] font-medium text-gray-500">{STAGE_LBL[stage]}</span>
                    <span className="text-[9px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded-full">{stageleads.length}</span>
                  </div>
                  <div className={`flex-1 rounded-lg p-2 ${STAGE_CLR[stage]} flex flex-col gap-2 overflow-y-auto`}>
                    {stageleads.map(lead => (
                      <div key={lead.id} className="bg-white border border-gray-100 rounded-lg p-2.5 cursor-pointer hover:border-blue-200 transition-colors">
                        <div className="text-xs font-medium text-gray-800 mb-0.5">{lead.nome} {lead.cognome}</div>
                        <div className="text-[10px] text-gray-400">{lead.mq_immobile ? `${lead.mq_immobile} mq ·` : ''} {lead.tipo_commessa}</div>
                        {lead.budget_stimato && (
                          <div className="text-xs font-medium text-blue-600 mt-1">€{Number(lead.budget_stimato).toLocaleString('it-IT')}</div>
                        )}
                        <div className="mt-1.5">
                          <span className={`text-[8px] font-medium px-1.5 py-0.5 rounded-full ${
                            lead.provenienza === 'Online' ? 'bg-green-50 text-green-700' :
                            lead.provenienza === 'Diretto' ? 'bg-amber-50 text-amber-700' : 'bg-purple-50 text-purple-700'
                          }`}>{lead.provenienza}</span>
                        </div>
                        {/* Quick stato change */}
                        <select
                          value={lead.stato}
                          onChange={e => updateStato(lead.id, e.target.value)}
                          onClick={e => e.stopPropagation()}
                          className="mt-2 w-full text-[9px] border border-gray-100 rounded px-1 py-0.5 bg-gray-50 text-gray-500"
                        >
                          {STAGES.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                    ))}
                    {stage !== 'KO' && (
                      <button onClick={() => setModal(true)} className="text-[10px] text-gray-400 border border-dashed border-gray-200 rounded-lg py-1.5 hover:border-blue-300 hover:text-blue-400 transition-colors">
                        + Aggiungi
                      </button>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Modal nuovo lead */}
      {modal && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50" onClick={e => e.target === e.currentTarget && setModal(false)}>
          <div className="bg-white rounded-xl shadow-xl p-6 w-96 max-h-[90vh] overflow-y-auto">
            <h2 className="text-sm font-medium text-gray-800 mb-4">Nuovo lead</h2>
            <div className="grid grid-cols-2 gap-3 mb-3">
              {[['nome','Nome'],['cognome','Cognome']].map(([k,l]) => (
                <div key={k}>
                  <label className="block text-[10px] text-gray-400 mb-1">{l}</label>
                  <input className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 bg-gray-50" value={form[k]} onChange={e => setForm({...form,[k]:e.target.value})} />
                </div>
              ))}
            </div>
            {[['telefono','Telefono'],['email','Email'],['indirizzo','Indirizzo immobile']].map(([k,l]) => (
              <div key={k} className="mb-3">
                <label className="block text-[10px] text-gray-400 mb-1">{l}</label>
                <input className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 bg-gray-50" value={form[k]} onChange={e => setForm({...form,[k]:e.target.value})} />
              </div>
            ))}
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">Provenienza</label>
                <select className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 bg-gray-50" value={form.provenienza} onChange={e => setForm({...form,provenienza:e.target.value})}>
                  {['Online','Store','Diretto','Passaparola','Architetto'].map(v => <option key={v}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">Tipo lavoro</label>
                <select className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 bg-gray-50" value={form.tipo_commessa} onChange={e => setForm({...form,tipo_commessa:e.target.value})}>
                  {['Ristrutturazione','Consulenza','Progettazione/DL','Finiture/Arredi'].map(v => <option key={v}>{v}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">MQ stimati</label>
                <input type="number" className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 bg-gray-50" value={form.mq_immobile} onChange={e => setForm({...form,mq_immobile:e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">Budget € stimato</label>
                <input type="number" className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 bg-gray-50" value={form.budget_stimato} onChange={e => setForm({...form,budget_stimato:e.target.value})} />
              </div>
            </div>
            <div className="mb-4">
              <label className="block text-[10px] text-gray-400 mb-1">Note</label>
              <textarea rows={3} className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 bg-gray-50 resize-none" value={form.note} onChange={e => setForm({...form,note:e.target.value})} />
            </div>
            <div className="flex gap-2 justify-end">
              <button onClick={() => setModal(false)} className="px-4 py-1.5 text-xs text-gray-500 border border-gray-200 rounded-lg hover:bg-gray-50">Annulla</button>
              <button onClick={save} disabled={saving || !form.nome || !form.cognome} className="px-4 py-1.5 text-xs bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-40">
                {saving ? 'Salvataggio...' : 'Salva lead'}
              </button>
            </div>
          </div>
        </div>
      )}

      <AIPanel
        context={aiContext}
        quickPrompts={[
          { label: '📊 Analisi pipeline settimanale',     prompt: 'Analizza la pipeline e dimmi i lead prioritari da seguire questa settimana con azioni concrete' },
          { label: '⚠️ Lead a rischio perdita',           prompt: 'Quali lead rischio di perdere? Cosa fare per recuperarli?' },
          { label: '✉️ Follow-up trattative',             prompt: 'Genera messaggi WhatsApp professionali di follow-up per i lead in trattativa' },
          { label: '📈 Tasso conversione per provenienza', prompt: 'Analizza il tasso di conversione per provenienza e dimmi cosa ottimizzare' },
        ]}
      />
    </div>
  )
}
