import AIPanel from '../components/AIPanel'
import { supabase } from '../lib/supabase'
import { useState, useEffect } from 'react'

export default function Subappalto() {
  // TODO: implementazione completa analoga a CRM.jsx e Preventivi.jsx
  // Il pattern è identico: useEffect → load da Supabase → render UI → AIPanel

  return (
    <div className="h-screen flex flex-col">
      <div className="bg-white border-b border-gray-100 px-5 py-3">
        <h1 className="text-sm font-medium text-gray-800">Subappalto</h1>
      </div>
      <div className="flex-1 flex items-center justify-center text-sm text-gray-400">
        Modulo Subappalto — implementare seguendo il pattern di CRM.jsx
      </div>
      <AIPanel context="Modulo Subappalto Darevô" quickPrompts={[]} />
    </div>
  )
}
