// src/components/crm/CRMPage.tsx
import { useState } from 'react'
import { useLeads, useLeadMutations, type LeadStatus } from '../../hooks/useLeads'
import { useAppStore } from '../../lib/store'

const STAGES: LeadStatus[] = ['Nuovo', 'Fissato', 'Trattativa', 'Firmato', 'KO']

const STAGE_LABELS: Record<LeadStatus, string> = {
  Nuovo: 'Nuovo',
  Fissato: 'App. fissato',
  Trattativa: 'In trattativa',
  Firmato: 'Firmato',
  KO: 'KO',
}

const PROV_COLOR: Record<string, string> = {
  Online: 'bg-teal-50 text-teal-800',
  Store: 'bg-purple-50 text-purple-800',
  Diretto: 'bg-amber-50 text-amber-800',
  Passaparola: 'bg-blue-50 text-blue-800',
  Architetto: 'bg-pink-50 text-pink-800',
}

export function CRMPage() {
  const { leads, isLoading, kpi } = useLeads()
  const { createLead, updateStatus } = useLeadMutations()
  const { setCurrentPage, setAiPanelOpen } = useAppStore()
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({
    nome: '', cognome: '', telefono: '', email: '',
    indirizzo: '', provenienza: 'Online', tipo_lavoro: 'Ristrutturazione',
    mq_stimati: '', budget_stimato: '', note: '',
  })

  setCurrentPage('crm')

  const handleSubmit = async () => {
    if (!form.nome || !form.cognome) return
    await createLead.mutateAsync({
      ...form,
      mq_stimati: form.mq_stimati ? Number(form.mq_stimati) : undefined,
      budget_stimato: form.budget_stimato ? Number(form.budget_stimato) : undefined,
      status: 'Nuovo',
      provenienza: form.provenienza as any,
      tipo_lavoro: form.tipo_lavoro as any,
    })
    setShowForm(false)
    setForm({ nome:'',cognome:'',telefono:'',email:'',indirizzo:'',provenienza:'Online',tipo_lavoro:'Ristrutturazione',mq_stimati:'',budget_stimato:'',note:'' })
  }

  if (isLoading) return <div className="p-6 text-sm text-gray-400">Caricamento lead...</div>

  return (
    <div className="flex flex-col h-full">
      {/* Topbar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-white border-b border-gray-100">
        <span className="text-sm font-medium">Pipeline Lead</span>
        <div className="flex gap-2">
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs border border-gray-200 rounded-lg hover:bg-gray-50"
          >
            + Nuovo lead
          </button>
          <button
            onClick={() => setAiPanelOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-lg hover:bg-blue-100"
          >
            ✨ AI
          </button>
        </div>
      </div>

      {/* KPI */}
      <div className="grid grid-cols-4 gap-3 p-4">
        {[
          { label: 'Lead totali', value: kpi.totale, sub: 'questo mese' },
          { label: 'In trattativa', value: kpi.inTrattativa, sub: 'da seguire' },
          { label: 'Firmati', value: kpi.firmati, sub: 'convertiti' },
          { label: 'Valore pipeline', value: `€${Math.round(kpi.valorePipeline / 1000)}k`, sub: 'potenziale' },
        ].map(({ label, value, sub }) => (
          <div key={label} className="bg-gray-50 rounded-lg p-3">
            <div className="text-[10px] text-gray-500">{label}</div>
            <div className="text-xl font-medium mt-0.5">{value}</div>
            <div className="text-[9px] text-gray-400 mt-0.5">{sub}</div>
          </div>
        ))}
      </div>

      {/* Pipeline kanban */}
      <div className="flex-1 overflow-x-auto px-4 pb-4">
        <div className="flex gap-3 h-full" style={{ minWidth: 800 }}>
          {STAGES.map(stage => {
            const stageLeads = leads.filter(l => l.status === stage)
            return (
              <div key={stage} className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-medium text-gray-500">
                    {STAGE_LABELS[stage]}
                  </span>
                  <span className="text-[9px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded-full">
                    {stageLeads.length}
                  </span>
                </div>
                <div className="bg-gray-50 rounded-lg p-2 flex flex-col gap-2 min-h-64">
                  {stageLeads.map(lead => (
                    <div
                      key={lead.id}
                      className="bg-white border border-gray-100 rounded-lg p-2.5 cursor-pointer hover:border-blue-200 transition-colors"
                      onClick={() => setAiPanelOpen(true)}
                    >
                      <div className="text-[11px] font-medium">{lead.nome} {lead.cognome}</div>
                      <div className="text-[9px] text-gray-500 mt-0.5">
                        {lead.mq_stimati ?? '?'} mq · {lead.tipo_lavoro}
                      </div>
                      {lead.budget_stimato && (
                        <div className="text-[11px] font-medium text-blue-600 mt-1">
                          €{lead.budget_stimato.toLocaleString('it-IT')}
                        </div>
                      )}
                      <span className={`inline-block mt-1.5 text-[8px] font-medium px-1.5 py-0.5 rounded ${PROV_COLOR[lead.provenienza] ?? 'bg-gray-100 text-gray-600'}`}>
                        {lead.provenienza}
                      </span>
                    </div>
                  ))}
                  {stage !== 'KO' && (
                    <button
                      onClick={() => setShowForm(true)}
                      className="text-[10px] text-gray-400 hover:text-gray-600 text-center py-1.5 border border-dashed border-gray-200 rounded-lg"
                    >
                      + Aggiungi
                    </button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Modal nuovo lead */}
      {showForm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center">
          <div className="bg-white rounded-xl shadow-lg p-5 w-96 max-h-[85vh] overflow-y-auto">
            <div className="text-sm font-medium mb-4">Nuovo lead</div>
            <div className="grid grid-cols-2 gap-3">
              {[
                ['nome', 'Nome', 'Mario'],
                ['cognome', 'Cognome', 'Rossi'],
                ['telefono', 'Telefono', '+39 333...'],
                ['email', 'Email', 'mario@email.com'],
              ].map(([key, label, ph]) => (
                <div key={key}>
                  <label className="text-[10px] text-gray-500 block mb-1">{label}</label>
                  <input
                    className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs"
                    placeholder={ph}
                    value={(form as any)[key]}
                    onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                  />
                </div>
              ))}
            </div>
            <div className="mt-3">
              <label className="text-[10px] text-gray-500 block mb-1">Indirizzo immobile</label>
              <input
                className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs"
                placeholder="Via Roma, 10 Milano"
                value={form.indirizzo}
                onChange={e => setForm(f => ({ ...f, indirizzo: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-3 mt-3">
              <div>
                <label className="text-[10px] text-gray-500 block mb-1">Provenienza</label>
                <select
                  className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs"
                  value={form.provenienza}
                  onChange={e => setForm(f => ({ ...f, provenienza: e.target.value }))}
                >
                  {['Online','Store','Diretto','Passaparola','Architetto'].map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-gray-500 block mb-1">Tipo lavoro</label>
                <select
                  className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs"
                  value={form.tipo_lavoro}
                  onChange={e => setForm(f => ({ ...f, tipo_lavoro: e.target.value }))}
                >
                  {['Ristrutturazione','Consulenza','Progettazione/DL','Finiture/Arredi'].map(o => <option key={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] text-gray-500 block mb-1">MQ stimati</label>
                <input type="number" className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs"
                  value={form.mq_stimati} onChange={e => setForm(f => ({ ...f, mq_stimati: e.target.value }))} />
              </div>
              <div>
                <label className="text-[10px] text-gray-500 block mb-1">Budget € stimato</label>
                <input type="number" className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs"
                  value={form.budget_stimato} onChange={e => setForm(f => ({ ...f, budget_stimato: e.target.value }))} />
              </div>
            </div>
            <div className="mt-3">
              <label className="text-[10px] text-gray-500 block mb-1">Note</label>
              <textarea
                className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs h-16 resize-none"
                value={form.note}
                onChange={e => setForm(f => ({ ...f, note: e.target.value }))}
              />
            </div>
            <div className="flex justify-end gap-2 mt-4">
              <button onClick={() => setShowForm(false)} className="px-4 py-1.5 text-xs text-gray-500 border border-gray-200 rounded-lg">
                Annulla
              </button>
              <button
                onClick={handleSubmit}
                disabled={createLead.isPending}
                className="px-4 py-1.5 text-xs bg-blue-50 text-blue-700 border border-blue-200 rounded-lg disabled:opacity-50"
              >
                {createLead.isPending ? 'Salvataggio...' : 'Salva lead'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
