import { useState, useRef, useEffect } from 'react'
import { Bot, Send, X, Sparkles } from 'lucide-react'
import { askClaude } from '../lib/claude'

export default function AIPanel({ context = '', quickPrompts = [] }) {
  const [open, setOpen]       = useState(false)
  const [history, setHistory] = useState([])
  const [input, setInput]     = useState('')
  const [loading, setLoading] = useState(false)
  const bottomRef             = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [history, loading])

  async function send(text) {
    if (!text.trim() || loading) return
    const userMsg = { role: 'user', content: context ? `${text}\n\nContesto: ${context}` : text }
    const newHistory = [...history, userMsg]
    setHistory(prev => [...prev, { role: 'user', display: text }])
    setInput('')
    setLoading(true)
    try {
      const reply = await askClaude(newHistory.map(m => ({ role: m.role, content: m.content ?? m.display })))
      setHistory(prev => [...prev, { role: 'assistant', display: reply, content: reply }])
    } catch (e) {
      setHistory(prev => [...prev, { role: 'assistant', display: '⚠️ ' + e.message, content: e.message }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <>
      {/* FAB */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-6 right-6 w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-lg hover:bg-blue-700 transition-colors z-40"
        >
          <Sparkles size={20} />
        </button>
      )}

      {/* Drawer */}
      {open && (
        <div className="fixed right-0 top-0 bottom-0 w-72 bg-white border-l border-gray-100 flex flex-col z-40 shadow-xl">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center">
                <Bot size={13} className="text-blue-600" />
              </div>
              <div>
                <div className="text-xs font-medium text-gray-800">Assistente AI</div>
                <div className="text-[10px] text-gray-400">Darevô · Claude</div>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="text-gray-400 hover:text-gray-600">
              <X size={15} />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3 flex flex-col gap-2">
            {history.length === 0 && (
              <div className="text-xs text-gray-400 bg-gray-50 rounded-lg p-3 leading-relaxed">
                Ciao! Sono il tuo assistente Darevô. Posso aiutarti con analisi, follow-up, preventivi e molto altro.
              </div>
            )}
            {history.map((m, i) => (
              <div
                key={i}
                className={`text-xs rounded-lg p-2.5 leading-relaxed whitespace-pre-wrap ${
                  m.role === 'user'
                    ? 'bg-blue-50 text-blue-900 self-end max-w-[90%]'
                    : 'bg-gray-50 text-gray-800'
                }`}
              >
                {m.display}
              </div>
            ))}
            {loading && (
              <div className="bg-gray-50 rounded-lg p-2.5 flex gap-1 items-center">
                {[0, 150, 300].map(d => (
                  <span
                    key={d}
                    className="w-1.5 h-1.5 rounded-full bg-gray-400 animate-bounce"
                    style={{ animationDelay: `${d}ms` }}
                  />
                ))}
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Quick prompts */}
          {quickPrompts.length > 0 && (
            <div className="px-3 pb-2 flex flex-col gap-1.5">
              {quickPrompts.map((qp, i) => (
                <button
                  key={i}
                  onClick={() => send(qp.prompt)}
                  className="text-left text-[10px] px-2.5 py-1.5 border border-gray-100 rounded-md text-gray-500 hover:bg-gray-50 hover:text-gray-700 transition-colors"
                >
                  {qp.label}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="p-3 border-t border-gray-100 flex gap-2">
            <textarea
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(input) } }}
              placeholder="Scrivi o premi Invio..."
              rows={2}
              className="flex-1 text-xs border border-gray-200 rounded-lg px-2.5 py-2 bg-gray-50 text-gray-800 resize-none focus:outline-none focus:ring-1 focus:ring-blue-300"
            />
            <button
              onClick={() => send(input)}
              disabled={loading || !input.trim()}
              className="self-end px-2.5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-40 transition-colors"
            >
              <Send size={13} />
            </button>
          </div>
        </div>
      )}
    </>
  )
}
