// src/components/shared/AIPanel.tsx
import { useState, useRef, useEffect } from 'react'
import { useAI } from '../../hooks/useAI'

const PAGE_CONTEXTS: Record<string, string> = {
  crm: 'Modulo CRM Lead: gestione pipeline commerciale, appuntamenti e conversioni',
  appuntamenti: 'Modulo Appuntamenti: calendario sopralluoghi e presentazioni preventivi',
  preventivi: 'Modulo Preventivi: computo metrico con 4 listini (Reg. Lombardia, Media Lomb., DEI, Milano) e analisi margini ANCE 2024',
  commesse: 'Modulo Commesse: cantieri attivi con SAL, pagamenti e cronoprogramma',
  sal: 'Modulo SAL & Contabilità: avanzamento lavori, fatturato, incassato, margini per cantiere',
  sicurezza: 'Modulo Sicurezza: documenti (POS, DVR, DURC, formazione) e scadenze',
  subappalto: 'Modulo Subappaltatori: albo fornitori, DURC, ordini e preventivi per cantiere',
}

const QUICK_ACTIONS: Record<string, [string, string][]> = {
  crm: [
    ['📋 Briefing giornaliero', 'Dammi un briefing rapido sulla pipeline: lead prioritari, follow-up da fare oggi'],
    ['⚠️ Lead a rischio', 'Quali lead sono a rischio abbandono? Cosa fare per recuperarli?'],
    ['✉️ Genera follow-up', 'Scrivi un messaggio WhatsApp professionale per i lead in trattativa'],
  ],
  preventivi: [
    ['🔍 Verifica prezzi', 'I prezzi del computo sono allineati al prezzario Regione Lombardia 2024-2025?'],
    ['💡 Ottimizza margini', 'Analizza i margini e suggerisci dove ottimizzare'],
    ['📄 Testo per cliente', 'Genera un testo descrittivo professionale del preventivo per il cliente'],
  ],
  sal: [
    ['📊 Analisi margini', 'Analizza il margine del cantiere: siamo in linea con il budget?'],
    ['💳 Sollecita pagamento', 'Genera una email professionale per sollecitare la rata in scadenza'],
  ],
  sicurezza: [
    ['🚨 Azioni urgenti', 'Cosa devo fare OGGI per le scadenze sicurezza? Piano d\'azione'],
    ['📅 Calendario scadenze', 'Elenca tutte le scadenze sicurezza dei prossimi 90 giorni'],
  ],
}

const DEFAULT_QUICK: [string, string][] = [
  ['📋 Briefing completo', 'Dammi un briefing completo: lead prioritari, cantieri critici, scadenze urgenti, pagamenti da incassare'],
  ['💰 Situazione finanziaria', 'Analizza la situazione finanziaria: fatturato, incassato, da incassare, margini cantieri attivi'],
  ['⚠️ Scadenze critiche', 'Quali sono le scadenze critiche dei prossimi 30 giorni tra sicurezza, SAL e pagamenti?'],
]

interface Props {
  pageContext: string
  onClose: () => void
}

export function AIPanel({ pageContext, onClose }: Props) {
  const ctx = PAGE_CONTEXTS[pageContext] ?? ''
  const { messages, loading, ask } = useAI(ctx)
  const [input, setInput] = useState('')
  const msgsRef = useRef<HTMLDivElement>(null)
  const quickActions = QUICK_ACTIONS[pageContext] ?? DEFAULT_QUICK

  useEffect(() => {
    if (msgsRef.current) msgsRef.current.scrollTop = msgsRef.current.scrollHeight
  }, [messages, loading])

  const send = () => {
    const t = input.trim()
    if (!t || loading) return
    setInput('')
    ask(t)
  }

  return (
    <div className="w-64 bg-white border-l border-gray-100 flex flex-col flex-shrink-0">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-full bg-blue-50 flex items-center justify-center text-xs">✨</div>
          <div>
            <div className="text-xs font-medium">Assistente AI</div>
            <div className="text-[9px] text-gray-400">Darevô · Claude</div>
          </div>
        </div>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-sm">✕</button>
      </div>

      {/* Messages */}
      <div ref={msgsRef} className="flex-1 overflow-y-auto p-2 flex flex-col gap-2">
        {messages.length === 0 && (
          <div className="text-[11px] text-gray-400 bg-gray-50 rounded-lg p-2.5 leading-relaxed">
            Ciao! Sono il tuo assistente Darevô. Gestisco pipeline, preventivi, cantieri, sicurezza e subappalto.
          </div>
        )}
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`text-[11px] rounded-lg px-2.5 py-2 leading-relaxed ${
              msg.role === 'user'
                ? 'bg-blue-50 text-blue-900 self-end max-w-[90%]'
                : 'bg-gray-50 text-gray-800'
            }`}
          >
            {msg.content}
          </div>
        ))}
        {loading && (
          <div className="flex gap-1 items-center px-2.5 py-2 bg-gray-50 rounded-lg w-16">
            {[0, 150, 300].map(d => (
              <div
                key={d}
                className="w-1 h-1 rounded-full bg-gray-400 animate-bounce"
                style={{ animationDelay: `${d}ms` }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Quick actions */}
      <div className="px-2 pb-1 flex flex-col gap-1">
        {quickActions.map(([label, prompt]) => (
          <button
            key={label}
            onClick={() => ask(prompt)}
            disabled={loading}
            className="text-left text-[10px] text-gray-500 hover:text-gray-700 hover:bg-gray-50 px-2 py-1.5 rounded-md border border-gray-100 disabled:opacity-50 transition-colors"
          >
            {label}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="p-2 border-t border-gray-100 flex gap-1.5">
        <textarea
          className="flex-1 text-[11px] border border-gray-200 rounded-lg px-2 py-1.5 resize-none h-12 bg-gray-50"
          placeholder="Chiedi qualsiasi cosa..."
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
        />
        <button
          onClick={send}
          disabled={loading || !input.trim()}
          className="px-2 py-1.5 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg text-xs disabled:opacity-40 self-end"
        >
          ↑
        </button>
      </div>
    </div>
  )
}
