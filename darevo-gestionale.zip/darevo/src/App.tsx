// src/App.tsx
import { BrowserRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { useEffect, useState } from 'react'
import { supabase } from './lib/supabase'
import { useAppStore } from './lib/store'
import { AIPanel } from './components/shared/AIPanel'

// Pages (lazy import in produzione con React.lazy)
import { CRMPage } from './components/crm/CRMPage'
import { AppuntamentiPage } from './components/crm/AppuntamentiPage'
import { PreventiviPage } from './components/preventivi/PreventiviPage'
import { CommessePage } from './components/cantieri/CommessePage'
import { SALPage } from './components/cantieri/SALPage'
import { SicurezzaPage } from './components/sicurezza/SicurezzaPage'
import { SubappaltoPage } from './components/subappalto/SubappaltoPage'
import { LoginPage } from './components/shared/LoginPage'

const qc = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 30_000, retry: 1 },
  },
})

const NAV = [
  { section: 'Pipeline', items: [
    { to: '/crm', icon: '👥', label: 'CRM Lead' },
    { to: '/appuntamenti', icon: '📅', label: 'Appuntamenti' },
  ]},
  { section: 'Progetti', items: [
    { to: '/preventivi', icon: '📄', label: 'Preventivi' },
    { to: '/commesse', icon: '🏗️', label: 'Commesse' },
  ]},
  { section: 'Cantiere', items: [
    { to: '/sal', icon: '📊', label: 'SAL & Contabilità' },
    { to: '/sicurezza', icon: '🛡️', label: 'Sicurezza' },
    { to: '/subappalto', icon: '🚛', label: 'Subappaltatori' },
  ]},
]

function Layout({ children }: { children: React.ReactNode }) {
  const { aiPanelOpen, toggleAiPanel, currentPage } = useAppStore()

  return (
    <div className="flex h-screen bg-gray-50 font-sans text-gray-900">
      {/* Sidebar */}
      <aside className="w-48 bg-white border-r border-gray-100 flex flex-col flex-shrink-0">
        <div className="px-4 py-3 border-b border-gray-100">
          <div className="text-sm font-medium">Darevô</div>
          <div className="text-xs text-gray-400">Gestionale edile</div>
        </div>
        <nav className="flex-1 overflow-y-auto py-1">
          {NAV.map(({ section, items }) => (
            <div key={section}>
              <div className="px-3 py-2 text-[9px] font-medium text-gray-400 uppercase tracking-wider">
                {section}
              </div>
              {items.map(({ to, icon, label }) => (
                <NavLink
                  key={to}
                  to={to}
                  className={({ isActive }) =>
                    `flex items-center gap-2 mx-1 px-3 py-1.5 rounded-md text-xs cursor-pointer transition-colors
                    ${isActive
                      ? 'bg-blue-50 text-blue-700 font-medium'
                      : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'}`
                  }
                >
                  <span>{icon}</span>
                  <span>{label}</span>
                </NavLink>
              ))}
            </div>
          ))}
        </nav>
        <div className="p-2 border-t border-gray-100">
          <button
            onClick={toggleAiPanel}
            className="w-full flex items-center gap-2 px-3 py-1.5 rounded-md text-xs text-gray-500 hover:bg-gray-50"
          >
            <span>✨</span>
            <span>Assistente AI</span>
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex overflow-hidden">
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>

        {/* AI Panel */}
        {aiPanelOpen && (
          <AIPanel
            pageContext={currentPage}
            onClose={toggleAiPanel}
          />
        )}
      </div>
    </div>
  )
}

export default function App() {
  const [session, setSession] = useState<unknown>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setLoading(false)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, s) => setSession(s))
    return () => subscription.unsubscribe()
  }, [])

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center text-gray-400 text-sm">
        Caricamento...
      </div>
    )
  }

  return (
    <QueryClientProvider client={qc}>
      <BrowserRouter>
        {!session ? (
          <LoginPage />
        ) : (
          <Layout>
            <Routes>
              <Route path="/" element={<Navigate to="/crm" replace />} />
              <Route path="/crm" element={<CRMPage />} />
              <Route path="/appuntamenti" element={<AppuntamentiPage />} />
              <Route path="/preventivi" element={<PreventiviPage />} />
              <Route path="/commesse" element={<CommessePage />} />
              <Route path="/sal" element={<SALPage />} />
              <Route path="/sicurezza" element={<SicurezzaPage />} />
              <Route path="/subappalto" element={<SubappaltoPage />} />
            </Routes>
          </Layout>
        )}
      </BrowserRouter>
    </QueryClientProvider>
  )
}
