// src/hooks/useAI.ts
// La chiamata Anthropic passa per una Supabase Edge Function:
// la API key non è mai esposta al browser.

import { useState, useCallback, useRef } from 'react'
import { supabase } from '../lib/supabase'

export interface AIMessage {
  role: 'user' | 'assistant'
  content: string
}

const SYSTEM_PROMPT = `Sei l'assistente AI integrato nel gestionale Darevô, impresa edile milanese 
specializzata in ristrutturazioni residenziali in Lombardia (Milano, Monza, Lecco, Como).
Conosci le 69 voci del capitolato Darevô con i 4 listini (Regione Lombardia 2024, 
Media Lombardia ×1.08, DEI 2024, Milano CCIAA) e i margini ANCE/CNA 2024.
Aiuti il team su: pipeline CRM, analisi preventivi, gestione cantieri, SAL, 
sicurezza, subappaltatori. Rispondi in italiano, conciso e operativo.`

export function useAI(pageContext?: string) {
  const [messages, setMessages] = useState<AIMessage[]>([])
  const [loading, setLoading] = useState(false)
  const historyRef = useRef<AIMessage[]>([])

  const ask = useCallback(async (userMessage: string) => {
    const userMsg: AIMessage = { role: 'user', content: userMessage }
    const contextualMessage = pageContext
      ? `${userMessage}\n\nContesto: ${pageContext}`
      : userMessage

    setMessages(prev => [...prev, userMsg])
    setLoading(true)

    historyRef.current = [...historyRef.current, { role: 'user', content: contextualMessage }]

    try {
      // Chiama la Edge Function Supabase (che ha la API key Anthropic server-side)
      const { data, error } = await supabase.functions.invoke('ai-chat', {
        body: {
          system: SYSTEM_PROMPT,
          messages: historyRef.current,
        },
      })

      if (error) throw error

      const assistantMsg: AIMessage = { role: 'assistant', content: data.content }
      historyRef.current = [...historyRef.current, { role: 'assistant', content: data.content }]
      setMessages(prev => [...prev, assistantMsg])
      return data.content as string
    } catch (err) {
      const errMsg: AIMessage = {
        role: 'assistant',
        content: 'Errore di connessione. Riprova.',
      }
      setMessages(prev => [...prev, errMsg])
    } finally {
      setLoading(false)
    }
  }, [pageContext])

  const reset = useCallback(() => {
    setMessages([])
    historyRef.current = []
  }, [])

  return { messages, loading, ask, reset }
}
