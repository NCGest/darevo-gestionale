// src/hooks/usePreventivi.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { db, supabase } from '../lib/supabase'

// -----------------------------------------------
// Dati statici capitolato (da file separato in produzione)
// -----------------------------------------------
export type Listino = 'Regione Lombardia' | 'Media Lombardia' | 'DEI' | 'Milano'

export interface VoceCatalogo {
  cod: string
  descrizione: string
  um: string
  prezzi: Record<Listino, number>
  incMateriale: number
  margLordo: number
  margNetto: number
}

// Prezzi per listino — fattore moltiplicatore su Listino Lombardo
export const FATTORI_LISTINO: Record<Listino, number> = {
  'Regione Lombardia': 1,
  'Media Lombardia': 1.08,
  'DEI': 0.88,      // ~12% sotto Lombardia
  'Milano': 1.27,    // ~27% sopra Lombardia (media del range)
}

// Recupera prezzo per una voce e un listino
export function getPrezzo(voce: VoceCatalogo, listino: Listino): number {
  return voce.prezzi[listino]
}

// -----------------------------------------------
// Hooks Supabase
// -----------------------------------------------
export function usePreventivi(clienteId?: string) {
  return useQuery({
    queryKey: ['preventivi', clienteId],
    queryFn: async () => {
      let q = db.preventivi().select('*, clienti(nome, cognome)').order('created_at', { ascending: false })
      if (clienteId) q = q.eq('cliente_id', clienteId)
      const { data, error } = await q
      if (error) throw error
      return data
    },
  })
}

export function usePreventivoDetail(preventivoId: string) {
  return useQuery({
    queryKey: ['preventivo', preventivoId],
    queryFn: async () => {
      const [{ data: prev }, { data: righe }] = await Promise.all([
        db.preventivi().select('*, clienti(*)').eq('id', preventivoId).single(),
        db.preventiviRighe().select('*').eq('preventivo_id', preventivoId).order('ordinamento'),
      ])
      return { preventivo: prev, righe: righe ?? [] }
    },
    enabled: !!preventivoId,
  })
}

export function usePreventivoMutations() {
  const qc = useQueryClient()

  const createPreventivo = useMutation({
    mutationFn: async (payload: {
      clienteId: string
      listino: Listino
      architetto?: string
    }) => {
      // Genera codice progressivo via funzione SQL
      const { data: codiceData } = await supabase.rpc('next_codice_preventivo')
      const { data, error } = await db.preventivi().insert({
        codice: codiceData,
        cliente_id: payload.clienteId,
        listino: payload.listino,
        architetto: payload.architetto,
        status: 'Bozza',
      }).select().single()
      if (error) throw error
      return data
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['preventivi'] }),
  })

  const addRiga = useMutation({
    mutationFn: async (riga: {
      preventivo_id: string
      voce_cod: string
      descrizione: string
      unita_misura: string
      quantita: number
      prezzo_unitario: number
      inc_materiale: number
      marg_lordo_pct: number
      marg_netto_pct: number
      ordinamento: number
    }) => {
      const { data, error } = await db.preventiviRighe().insert(riga).select().single()
      if (error) throw error
      return data
    },
    onSuccess: (_, v) => qc.invalidateQueries({ queryKey: ['preventivo', v.preventivo_id] }),
  })

  const updateRiga = useMutation({
    mutationFn: async ({ id, quantita }: { id: string; quantita: number; preventivo_id: string }) => {
      const { error } = await db.preventiviRighe().update({ quantita }).eq('id', id)
      if (error) throw error
    },
    onSuccess: (_, v) => qc.invalidateQueries({ queryKey: ['preventivo', v.preventivo_id] }),
  })

  const deleteRiga = useMutation({
    mutationFn: async ({ id, preventivo_id }: { id: string; preventivo_id: string }) => {
      const { error } = await db.preventiviRighe().delete().eq('id', id)
      if (error) throw error
    },
    onSuccess: (_, v) => qc.invalidateQueries({ queryKey: ['preventivo', v.preventivo_id] }),
  })

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await db.preventivi().update({ status }).eq('id', id)
      if (error) throw error
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['preventivi'] }),
  })

  return { createPreventivo, addRiga, updateRiga, deleteRiga, updateStatus }
}
