// src/hooks/useLeads.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useEffect } from 'react'
import { db, supabase } from '../lib/supabase'

export type LeadStatus = 'Nuovo' | 'Fissato' | 'Trattativa' | 'Firmato' | 'KO'

export interface Lead {
  id: string
  nome: string
  cognome: string
  telefono?: string
  email?: string
  indirizzo?: string
  provenienza: string
  tipo_lavoro: string
  mq_stimati?: number
  budget_stimato?: number
  note?: string
  status: LeadStatus
  data_appuntamento?: string
  architetto?: string
  store?: string
  data_inserimento: string
  created_at: string
}

export function useLeads() {
  const qc = useQueryClient()

  // Query
  const { data: leads = [], isLoading } = useQuery({
    queryKey: ['leads'],
    queryFn: async () => {
      const { data, error } = await db.leads()
        .select('*')
        .order('created_at', { ascending: false })
      if (error) throw error
      return data as Lead[]
    },
  })

  // Realtime subscription
  useEffect(() => {
    const channel = supabase
      .channel('leads-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'leads' }, () => {
        qc.invalidateQueries({ queryKey: ['leads'] })
      })
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [qc])

  // KPI calcolati
  const kpi = {
    totale: leads.length,
    inTrattativa: leads.filter(l => l.status === 'Trattativa').length,
    firmati: leads.filter(l => l.status === 'Firmato').length,
    valorePipeline: leads
      .filter(l => l.status !== 'KO')
      .reduce((s, l) => s + (l.budget_stimato ?? 0), 0),
  }

  return { leads, isLoading, kpi }
}

export function useLeadMutations() {
  const qc = useQueryClient()

  const createLead = useMutation({
    mutationFn: async (lead: Omit<Lead, 'id' | 'created_at' | 'data_inserimento'>) => {
      const { data, error } = await db.leads().insert(lead).select().single()
      if (error) throw error
      return data
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leads'] }),
  })

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: LeadStatus }) => {
      const { error } = await db.leads().update({ status }).eq('id', id)
      if (error) throw error
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leads'] }),
  })

  const deleteLead = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await db.leads().delete().eq('id', id)
      if (error) throw error
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['leads'] }),
  })

  return { createLead, updateStatus, deleteLead }
}
