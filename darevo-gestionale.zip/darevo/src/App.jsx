import { BrowserRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom'
import { Users, Calendar, FileText, Building2, BarChart2, Shield, Truck, Settings, LogOut } from 'lucide-react'
import CRM from './pages/CRM'
import Appuntamenti from './pages/Appuntamenti'
import Preventivi from './pages/Preventivi'
import Commesse from './pages/Commesse'
import SAL from './pages/SAL'
import Sicurezza from './pages/Sicurezza'
import Subappalto from './pages/Subappalto'

const NAV = [
  { label: 'Pipeline', items: [
    { to: '/crm',          icon: Users,     label: 'CRM Lead'       },
    { to: '/appuntamenti', icon: Calendar,  label: 'Appuntamenti'   },
  ]},
  { label: 'Progetti', items: [
    { to: '/preventivi',   icon: FileText,  label: 'Preventivi'     },
    { to: '/commesse',     icon: Building2, label: 'Commesse'       },
  ]},
  { label: 'Cantiere', items: [
    { to: '/sal',          icon: BarChart2, label: 'SAL & Contabilità' },
    { to: '/sicurezza',    icon: Shield,    label: 'Sicurezza'      },
    { to: '/subappalto',   icon: Truck,     label: 'Subappaltatori' },
  ]},
]

function Sidebar() {
  return (
    <aside className="w-52 bg-white border-r border-gray-100 flex flex-col h-screen fixed left-0 top-0 z-10">
      <div className="px-4 py-4 border-b border-gray-100">
        <div className="text-sm font-semibold text-gray-900 tracking-tight">Darevô</div>
        <div className="text-xs text-gray-400 mt-0.5">Gestionale edile</div>
      </div>

      <nav className="flex-1 overflow-y-auto py-2">
        {NAV.map(group => (
          <div key={group.label} className="mb-1">
            <div className="px-3 pt-3 pb-1 text-[9px] font-medium text-gray-400 uppercase tracking-widest">
              {group.label}
            </div>
            {group.items.map(({ to, icon: Icon, label }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  `flex items-center gap-2 mx-1 px-3 py-1.5 rounded-md text-xs transition-colors ${
                    isActive
                      ? 'bg-blue-50 text-blue-600 font-medium'
                      : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
                  }`
                }
              >
                <Icon size={14} />
                {label}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      <div className="border-t border-gray-100 p-2">
        <button className="flex items-center gap-2 w-full px-3 py-1.5 text-xs text-gray-400 hover:text-gray-600 rounded-md hover:bg-gray-50">
          <Settings size={14} />
          Impostazioni
        </button>
      </div>
    </aside>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="flex min-h-screen bg-gray-50">
        <Sidebar />
        <main className="flex-1 ml-52 min-h-screen">
          <Routes>
            <Route path="/" element={<Navigate to="/crm" replace />} />
            <Route path="/crm"          element={<CRM />} />
            <Route path="/appuntamenti" element={<Appuntamenti />} />
            <Route path="/preventivi"   element={<Preventivi />} />
            <Route path="/commesse"     element={<Commesse />} />
            <Route path="/sal"          element={<SAL />} />
            <Route path="/sicurezza"    element={<Sicurezza />} />
            <Route path="/subappalto"   element={<Subappalto />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}
