// src/lib/supabase.ts
import { createClient } from '@supabase/supabase-js'
import type { Database } from '../types/database'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Variabili Supabase mancanti nel file .env')
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
  realtime: {
    params: { eventsPerSecond: 10 },
  },
})

// Helper tipizzati per le query più comuni
export const db = {
  leads: () => supabase.from('leads'),
  clienti: () => supabase.from('clienti'),
  preventivi: () => supabase.from('preventivi'),
  preventiviRighe: () => supabase.from('preventivi_righe'),
  commesse: () => supabase.from('commesse'),
  salVoci: () => supabase.from('sal_voci'),
  pagamenti: () => supabase.from('pagamenti'),
  lavoriExtra: () => supabase.from('lavori_extra'),
  documentiSicurezza: () => supabase.from('documenti_sicurezza'),
  subappaltatori: () => supabase.from('subappaltatori'),
  subappaltoOrdini: () => supabase.from('subappalto_ordini'),
  giornaleCantiere: () => supabase.from('giornale_cantiere'),
}
