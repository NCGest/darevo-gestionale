// src/lib/store.ts
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

type Listino = 'Regione Lombardia' | 'Media Lombardia' | 'DEI' | 'Milano'

interface AppState {
  // Preferenze utente
  listinoDefault: Listino
  setListinoDefault: (l: Listino) => void

  // Navigazione corrente (per contesto AI)
  currentPage: string
  setCurrentPage: (page: string) => void

  // Pannello AI aperto
  aiPanelOpen: boolean
  toggleAiPanel: () => void
  setAiPanelOpen: (open: boolean) => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      listinoDefault: 'Regione Lombardia',
      setListinoDefault: (l) => set({ listinoDefault: l }),

      currentPage: 'crm',
      setCurrentPage: (page) => set({ currentPage: page }),

      aiPanelOpen: false,
      toggleAiPanel: () => set((s) => ({ aiPanelOpen: !s.aiPanelOpen })),
      setAiPanelOpen: (open) => set({ aiPanelOpen: open }),
    }),
    { name: 'darevo-prefs', partialize: (s) => ({ listinoDefault: s.listinoDefault }) }
  )
)
